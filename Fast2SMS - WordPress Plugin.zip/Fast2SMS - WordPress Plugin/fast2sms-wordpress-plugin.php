<?php
/**
 * Plugin Name: Fast2SMS - WordPress Plugin
 * Description: A Simple and Free WordPress Plugin that Integrates Fast2SMS Services.
 * Version: 1.0
 * Author: Adenwalla - Innovative Solutions
 * Author URI: https://adenwalla.in/
 * License: GPL-2.0+
 */

// Prevent direct access to the plugin file
if (!defined('ABSPATH')) {
    exit;
}

// Add the plugin settings menu and submenu to primary zone
function sms_activation_settings_menu() {
    add_menu_page(
        'SMS Activation',
        'SMS Activation',
        'manage_options',
        'sms-activation',
        'sms_activation_settings_page',
        'dashicons-admin-plugins',
        20
    );

    add_submenu_page(
        'sms-activation',
        'Send SMS',
        'Send SMS',
        'manage_options',
        'sms-activation-send-sms',
        'sms_activation_send_sms_page'
    );
}
add_action('admin_menu', 'sms_activation_settings_menu');

// Render the plugin settings page
function sms_activation_settings_page() {
    // Check if user has sufficient permissions
    if (!current_user_can('manage_options')) {
        wp_die('You do not have sufficient permissions to access this page.');
    }

    // Handle form submission
    if (isset($_POST['sms_activation_submit'])) {
        $api_key = isset($_POST['sms_activation_api_key']) ? sanitize_text_field($_POST['sms_activation_api_key']) : '';
        $is_active = isset($_POST['sms_activation_active']) ? 1 : 0;
        $sms_type = isset($_POST['sms_type']) ? sanitize_text_field($_POST['sms_type']) : '';
        $wc_activation = isset($_POST['wc_activation']) ? 1 : 0;
        $wc_sms_type = isset($_POST['wc_sms_type']) ? sanitize_text_field($_POST['wc_sms_type']) : '';
        $user_activation = isset($_POST['user_activation']) ? 1 : 0;
        $user_sms_type = isset($_POST['user_sms_type']) ? sanitize_text_field($_POST['user_sms_type']) : '';

        update_option('sms_activation_api_key', $api_key);
        update_option('sms_activation_active', $is_active);
        update_option('sms_type', $sms_type);
        update_option('wc_activation', $wc_activation);
        update_option('wc_sms_type', $wc_sms_type);
        update_option('user_activation', $user_activation);
        update_option('user_sms_type', $user_sms_type);

        echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
    }

    // Get current settings values
    $api_key = get_option('sms_activation_api_key', '');
    $is_active = get_option('sms_activation_active', 0);
    $sms_type = get_option('sms_type', 'otp');
    $wc_activation = get_option('wc_activation', 0);
    $wc_sms_type = get_option('wc_sms_type', 'otp');
    $user_activation = get_option('user_activation', 0);
    $user_sms_type = get_option('user_sms_type', 'otp');
    ?>
    <div class="wrap">
        <h1>SMS Activation Settings</h1>
        <form method="post">
            <h2>API Settings</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">API Key:</th>
                    <td>
                        <input type="text" name="sms_activation_api_key" value="<?php echo esc_attr($api_key); ?>">
                    </td>
                </tr>
                <tr>
                    <th scope="row">SMS Type:</th>
                    <td>
                        <select name="sms_type">
                            <option value="otp" <?php selected($sms_type, 'otp'); ?>>OTP</option>
                            <option value="dlt" <?php selected($sms_type, 'dlt'); ?>>DLT</option>
                            <option value="quick_sms" <?php selected($sms_type, 'quick_sms'); ?>>Quick SMS</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Activate Plugin:</th>
                    <td>
                        <label>
                            <input type="checkbox" name="sms_activation_active" <?php checked($is_active, 1); ?>>
                            Activate SMS
                        </label>
                    </td>
                </tr>
            </table>
            <h2>WooCommerce Settings</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">Activate WooCommerce Integration:</th>
                    <td>
                        <label>
                            <input type="checkbox" name="wc_activation" <?php checked($wc_activation, 1); ?>>
                            Activate WooCommerce SMS
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">SMS Type for WooCommerce:</th>
                    <td>
                        <select name="wc_sms_type">
                            <option value="otp" <?php selected($wc_sms_type, 'otp'); ?>>OTP</option>
                            <option value="dlt" <?php selected($wc_sms_type, 'dlt'); ?>>DLT</option>
                            <option value="quick_sms" <?php selected($wc_sms_type, 'quick_sms'); ?>>Quick SMS</option>
                        </select>
                    </td>
                </tr>
            </table>
            <h2>User Registration Settings</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">Activate User Registration Integration:</th>
                    <td>
                        <label>
                            <input type="checkbox" name="user_activation" <?php checked($user_activation, 1); ?>>
                            Activate User Registration SMS
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">SMS Type for User Registration:</th>
                    <td>
                        <select name="user_sms_type">
                            <option value="otp" <?php selected($user_sms_type, 'otp'); ?>>OTP</option>
                            <option value="dlt" <?php selected($user_sms_type, 'dlt'); ?>>DLT</option>
                            <option value="quick_sms" <?php selected($user_sms_type, 'quick_sms'); ?>>Quick SMS</option>
                        </select>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="sms_activation_submit" class="button-primary" value="Save Changes">
            </p>
        </form>
    </div>
    <?php
}

// Render the send SMS page
function sms_activation_send_sms_page() {
    // Check if user has sufficient permissions
    if (!current_user_can('manage_options')) {
        wp_die('You do not have sufficient permissions to access this page.');
    }

    // Handle form submission
    if (isset($_POST['sms_activation_send_sms'])) {
        $number = isset($_POST['sms_activation_number']) ? sanitize_text_field($_POST['sms_activation_number']) : '';
        $message = isset($_POST['sms_activation_message']) ? sanitize_text_field($_POST['sms_activation_message']) : '';

        // Call your function to send the SMS
        sms_activation_send_sms($number, $message, false);
    }
    ?>
    <div class="wrap">
        <h1>Send SMS</h1>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th scope="row">Number:</th>
                    <td>
                        <input type="text" name="sms_activation_number" value="">
                    </td>
                </tr>
                <tr>
                    <th scope="row">Message:</th>
                    <td>
                        <textarea name="sms_activation_message" rows="5" cols="50"></textarea>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="sms_activation_send_sms" class="button-primary" value="Send SMS">
            </p>
        </form>
    </div>
    <?php
}

// Function to send the SMS
function send_order_sms_notification($order_id, $status) {
    // Retrieve the order details
    $order = wc_get_order($order_id);

    // Retrieve the customer phone number
    $billing_phone = $order->get_billing_phone();

    // Retrieve the order ID
    $order_number = $order->get_order_number();

    // Prepare the SMS message based on order status
    switch ($status) {
        case 'completed':
            $message = "Thank you for your order. Your order ID is " . $order_number . ". It has been completed.";
            break;
        case 'cancelled':
            $message = "Your order with ID " . $order_number . " has been cancelled.";
            break;
        case 'refunded':
            $message = "Your order with ID " . $order_number . " has been refunded.";
            break;
        case 'pending':
            $message = "Your order with ID " . $order_number . " is pending.";
            break;
        case 'on-hold':
            $message = "Your order with ID " . $order_number . " is on hold.";
            break;
        case 'created':
            $message = "Order created successfully : " . $order_number . " is your order id.";
            break;    
        default:
            $message = "Your order with ID " . $order_number . " has been updated.";
            break;
    }

    // Call your function to send the SMS
    sms_activation_send_sms($billing_phone, $message, true);
}

// Send SMS on order status change
function send_order_sms_on_status_change($order_id, $old_status, $new_status, $order) {
    send_order_sms_notification($order_id, $new_status);
}
add_action('woocommerce_order_status_changed', 'send_order_sms_on_status_change', 10, 4);

// Send SMS on order creation
function send_order_sms_on_creation($order_id) {
    send_order_sms_notification($order_id, 'created');
}

add_action('woocommerce_new_order', 'send_order_sms_on_creation');

// Function to send the SMS
function sms_activation_send_sms($number, $message, $woocommerce) {
    $is_active = get_option('sms_activation_active', '');
    if (!$is_active) {
        echo '<div class="notice notice-error"><p>SMS notifications not activated. Please configure the plugin settings.</p></div>';
        return;
    }
    
    // Retrieve the API key from the settings page
    $api_key = get_option('sms_activation_api_key', '');
    
    if ($woocommerce) {
        $is_wc_active = get_option('wc_activation', '');
        if (!$is_wc_active) {
            echo '<div class="notice notice-error"><p>WooCommerce notification not activated. Please configure the plugin settings.</p></div>';
            return;
        }
        $sms_type = get_option('wc_sms_type', '');
    } else {
        $sms_type = get_option('sms_type', '');
    }
    
    // Check if the API key is available
    if (empty($api_key)) {
        echo '<div class="notice notice-error"><p>API key is not set. Please configure the plugin settings.</p></div>';
        return;
    }

    // Prepare the SMS parameters
    if($sms_type == 'otp'){
        $fields = array(
            "variables_values" => $message,
            "route" => $sms_type,
            "numbers" => $number,
        );
    }else if($sms_type == 'dlt'){
        $fields = array(
            "message" => $message,
            "sender_id" => "FSTSMS",
            "language" => "english",
            "route" => "v3",
            "numbers" => $number,
        );
    }else if($sms_type == 'q'){
        $fields = array(
            "message" => $message,
            "language" => "english",
            "route" => $sms_type,
            "numbers" => $number,
        );
    }

    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => json_encode($fields),
        CURLOPT_HTTPHEADER => array(
            "authorization: " . $api_key,
            "accept: */*",
            "cache-control: no-cache",
            "content-type: application/json"
        ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    if ($err) {
        echo '<div class="notice notice-error"><p>cURL Error: ' . $err . '</p></div>';
    } else {
        echo '<div class="notice notice-success"><p>SMS sent successfully.</p></div>';
        // Uncomment the line below if you want to see the response from the API
        // echo '<pre>' . 
    }    
}

// Add phone number field to user registration form
function add_phone_number_field() {
    ?>
    <p>
        <label for="phone_number"><?php esc_html_e('Phone Number', 'text-domain'); ?><br>
            <input type="text" name="phone_number" id="phone_number" class="input" value="<?php echo esc_attr( isset( $_POST['phone_number'] ) ? $_POST['phone_number'] : '' ); ?>" required>
        </label>
    </p>
    <?php
}
add_action('register_form', 'add_phone_number_field');

// Validate and save phone number field during user registration
function validate_phone_number_field($errors, $sanitized_user_login, $user_email) {
    if (empty($_POST['phone_number'])) {
        $errors->add('phone_number_error', __('Please enter your phone number.', 'text-domain'));
    }
    return $errors;
}
add_filter('registration_errors', 'validate_phone_number_field', 10, 3);

function save_phone_number_field($user_id) {
    if (!empty($_POST['phone_number'])) {
        update_user_meta($user_id, 'phone_number', sanitize_text_field($_POST['phone_number']));
    }
}
add_action('user_register', 'save_phone_number_field');

// Function to send a confirmation SMS
function send_registration_confirmation_sms($user_id) {
    // Retrieve the user's phone number
    $phone_number = get_user_meta($user_id, 'phone_number', true);

    // Prepare the SMS message
    $message = "Thank you for registering. Your account has been successfully created.";

    // Send the SMS
    sms_activation_send_sms($phone_number, $message, false);
}
add_action('user_register', 'send_registration_confirmation_sms', 10, 1);

function check_woocommerce_activation() {
    // Check if WooCommerce notification is active
    $woocommerce_notification = get_option('woocommerce_notification');

    if ($woocommerce_notification === 'active') {
        // WooCommerce notification is active, check if WooCommerce plugin is active
        if (!is_plugin_active('woocommerce/woocommerce.php')) {
            // WooCommerce plugin is not active, display notice to install WooCommerce
            add_action('admin_notices', 'install_woocommerce_notice');
        }
    }
}

function install_woocommerce_notice() {
    ?>
    <div class="notice notice-error">
        <p><?php _e('Please install and activate the WooCommerce plugin.', 'text-domain'); ?></p>
    </div>
    <?php
}

add_action('admin_init', 'check_woocommerce_activation');